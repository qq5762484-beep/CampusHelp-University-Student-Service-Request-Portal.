# Schedule, dependencies and budget

## Baseline calendar
**Draft assumption:** Day 1 is Monday 9 Nov 2026. This is an editable planning assumption, not a confirmed lecturer assignment date. Working days exclude Saturday and Sunday.

| Day | Calendar date | Planned work / checkpoint |
|---|---|---|
| D1 | 9 Nov 2026 | Kickoff, T01/T02 start, repo and access |
| D2 | 10 Nov 2026 | T01–T03 initiation deliverables; M1 due |
| D3 | 11 Nov 2026 | T04–T06 planning work |
| D4 | 12 Nov 2026 | Schedule, wireframes, risk/quality plan; M2 due |
| D5 | 13 Nov 2026 | Prototype build; monitoring checkpoint 2 |
| D6 | 16 Nov 2026 | Simulated change request; evaluate impact |
| D7 | 17 Nov 2026 | Prototype and tests; M3 due |
| D8 | 18 Nov 2026 | Monitoring checkpoint 3; verification begins |
| D9 | 19 Nov 2026 | Final review, report consolidation |
| D10 | 20 Nov 2026 | Closure, M4 due and submission |

## Task estimates and ownership
| ID | Task | Owner role | Effort | Priority | Milestone |
|---|---|---|---:|---|---|
| T01 | Develop project charter | A | 4 h | High | M1 |
| T02 | Gather stakeholder requirements | B | 4 h | High | M1 |
| T03 | Prepare scope and WBS | C | 4 h | Medium | M1 |
| T04 | Prepare schedule, dependencies and budget | A | 4 h | High | M2 |
| T05 | Design initial wireframes | B | 4 h | Medium | M2 |
| T06 | Develop risk register and quality plan | C | 4 h | Medium | M2 |
| T07 | Create student request interface prototype | B | 4 h | High | M3 |
| T08 | Create administrator dashboard prototype | A | 4 h | High | M3 |
| T09 | Prepare and execute prototype test cases | C | 4 h | High | M3 |
| T10 | Evaluate and document change request | A | 3 h | Medium | M4 |
| T11 | Perform final verification and issue review | C | 3 h | High | M4 |
| T12 | Consolidate final report and closure documents | B | 3 h | Medium | M4 |
| | **Total** | | **45 h** | | |

## Dependencies (finish-to-start)
- T02 has no predecessor.
- T03 depends on T01.
- T04 depends on T03.
- T05 depends on T02.
- T07 and T08 depend on T05.
- T09 depends on both T07 and T08.
- T11 depends on both T09 and T10.
- T12 depends on T11.
- T06 and T10 are not given formal predecessors in the assignment; schedule them early enough to protect their milestones.

```mermaid
flowchart TD
 T01[T01 Charter] --> T03[T03 Scope and WBS]
 T03 --> T04[T04 Schedule and budget]
 T02[T02 Requirements] --> T05[T05 Wireframes]
 T05 --> T07[T07 Student prototype]
 T05 --> T08[T08 Admin prototype]
 T07 --> T09[T09 Testing]
 T08 --> T09
 T10[T10 Change request] --> T11[T11 Final verification]
 T09 --> T11
 T11 --> T12[T12 Final report]
 T06[T06 Risk and quality plan]
```

## Critical delay-sensitive tasks
1. **T02 requirements:** T05 cannot be finalized until core user needs and fields are agreed; delay propagates to both prototype tasks and testing.
2. **T05 wireframes:** T07 and T08 depend on it; a late design baseline compresses build and test time.
3. **T07/T08 prototypes:** T09 requires both screens; a delay in either blocks test completion and threatens M3.
4. **T09 testing:** T11 requires test evidence, so unresolved defects or missing results threaten closure.

## Budget
Rate: **50,000 UZS per person-hour**.

| Work | Hours | Cost |
|---|---:|---:|
| T01–T09 | 36 | 1,800,000 UZS |
| T10–T12 | 9 | 450,000 UZS |
| **Total** | **45** | **2,250,000 UZS** |

Formula: 45 hours × 50,000 UZS/hour = **2,250,000 UZS**. This is an imputed labor estimate for the assignment, not a cash expenditure. External service costs are assumed to be zero.

## Milestones
| Milestone | Deliverables | Due date (assumed baseline) |
|---|---|---|
| M1 — Project Initiation | Charter, requirements, stakeholders, initial WBS | 10 Nov 2026 |
| M2 — Project Planning | Schedule, resource estimate, risk register, mockups, quality plan | 12 Nov 2026 |
| M3 — Project Execution | Student screen, admin dashboard, prototype demo, test cases | 17 Nov 2026 |
| M4 — Monitoring and Closure | Change request, verification, final status, consolidated submission | 20 Nov 2026 |
