# Risk register

Probability and impact are qualitative planning ratings. Review and update them at each checkpoint.

| ID | Risk | Probability | Impact | Owner | Mitigation / response | Trigger |
|---|---|---|---|---|---|---|
| R1 | A team member is absent or unavailable | Medium | High | A | Keep task notes current; cross-train; reassign critical path work with agreement | Missed check-in or task date |
| R2 | Design work is delayed | High | Medium | B | Prioritize required fields and core flows; timebox visual polish | Wireframes not reviewed by D4 |
| R3 | GitHub access or invitation problem | Medium | Medium | A | Verify all three accounts and permissions on D1; retain local copies | Member cannot access repo |
| R4 | Requirements change late | Medium | High | A | Use formal change request; assess schedule/cost; defer nonessential scope | New feature requested |
| R5 | Prototype defects or confusing flow | Medium | High | C | Peer review and execute six tests before M3 | Any critical test fails |
| R6 | Dates assumed incorrectly | Medium | High | A | Confirm lecturer start date and reset all due dates before milestone creation | Start date differs from baseline |
| R7 | Incomplete peer reviews / contribution evidence | Medium | High | All | Schedule three PRs and cross-review explicitly; record issue updates individually | PR or review absent by D8 |

**Most serious risk:** R4 (late scope change) has high impact because adding functionality can affect scope, effort, dependencies and milestone dates within a fixed ten-day window. Formal impact analysis and a defer/reject option protect the baseline.
