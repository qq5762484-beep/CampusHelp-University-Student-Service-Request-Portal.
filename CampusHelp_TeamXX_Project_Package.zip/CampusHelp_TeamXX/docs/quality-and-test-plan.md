# Quality plan and test cases

## Quality approach
- Review requirements and acceptance criteria before prototype work.
- Use peer review for each contributed document/prototype change.
- Test the documented/clickable prototype; clearly mark simulated behavior.
- Record actual result and Pass/Fail only after execution. The expected results below are not pre-filled as actual results.
- Defects are logged as GitHub Issues with severity, reproduction steps and evidence.
- Exit criteria: six test cases executed; critical defects fixed or explicitly accepted as unresolved; evidence linked to T09/T11.

## Test cases
| Test ID | Test steps | Expected result | Actual result | Status |
|---|---|---|---|---|
| TC-01 Required fields | Submit form with required fields blank | Validation prevents submission and identifies missing fields | To be executed | Not run |
| TC-02 Category | Open category selector and choose Library Assistance | Selected category is retained in request summary | To be executed | Not run |
| TC-03 Priority | Choose High priority and submit valid request | High priority is displayed in confirmation/request list | To be executed | Not run |
| TC-04 Confirmation / ID | Submit a valid request | Confirmation state displays a generated unique-looking request ID | To be executed | Not run |
| TC-05 Status visibility | Find a request in tracking/admin view and inspect status | New/In Progress/Completed status is visible and understandable | To be executed | Not run |
| TC-06 Dashboard | Open administrator dashboard | Open, ongoing and completed counts are displayed | To be executed | Not run |

## Prototype limitations
The HTML mockup uses in-browser demonstration data only. It does not authenticate users, persist requests on a server, deliver email, enforce role-based access, or provide secure production data storage. Test outcomes must be entered by a student after trying the prototype in a browser.
