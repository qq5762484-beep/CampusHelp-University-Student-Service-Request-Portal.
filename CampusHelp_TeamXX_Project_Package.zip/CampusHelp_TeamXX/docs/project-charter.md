# Project Charter — CampusHelp

## Purpose and business problem
The university currently receives IT support, classroom maintenance, library assistance and administrative requests through email and paper forms. Requests are difficult to centralize, assign, track and report. CampusHelp is a proposed web-based student service request portal intended to demonstrate a consistent request lifecycle.

## Objectives
1. Specify a centralized process for students to submit service requests.
2. Represent all six required capabilities in requirements and interface designs.
3. Demonstrate student submission and administrator triage/status monitoring in a clickable prototype.
4. Complete the four project milestones within ten working days.
5. Verify the prototype flow with at least six documented test cases.

## Sponsor and stakeholders
- Sponsor: University Administration (simulated).
- Project manager: Student A (name to be completed).
- Students, IT support, administrators, maintenance staff, library staff and administrative service staff.

## Scope
**In scope:** request submission; category and priority selection; unique request ID concept; administrator assignment; status updates; dashboard mockup; requirements; wireframes/prototype; test cases; project documentation and GitHub collaboration evidence.

**Out of scope:** real authentication/authorization, production hosting, database persistence, live email/SMS integrations, integrations with university systems, service-level automation and production security certification.

## Deliverables
Project charter, stakeholder/requirements register, WBS, schedule and budget, four milestones, twelve GitHub Issues, Kanban/Table/Roadmap project views, risk register, change request decision, clickable prototype, test results, monitoring checkpoints, closure report and consolidated PDF.

## Assumptions
- Exactly three students participate.
- Lecturer's assignment date is the baseline start date; this draft assumes 9 Nov 2026 only to populate example dates.
- Team members can access GitHub and accept repository invitations.
- No paid external services are required.
- Prototype data is illustrative and not real student data.

## Constraints
Ten working days; three-person team; 45 planned person-hours; no external service charges; simulated service integrations.

## Measurable success criteria
- All six proposed system capabilities are represented in requirements or interface designs.
- All twelve mandatory work issues are created, assigned, labelled and linked to the correct milestone.
- Four milestones are created with real calendar due dates.
- All six prototype test cases have recorded actual results and pass/fail outcomes before closure.
- Each student owns at least four tasks, contributes at least one file through a PR, reviews another member's work and posts at least three meaningful issue updates.
- All deliverables and working GitHub links are included in the final report.

## Governance and acceptance
Student A coordinates scope, schedule, milestones and change control. Student B owns requirements, wireframes, prototype and report consolidation. Student C owns WBS, risk, quality and test coordination. Deliverables are accepted after peer review and evidence is linked to the corresponding issue. Sponsor approval is simulated for this academic exercise.
