# Progress monitoring — checkpoint templates

Record actual status in GitHub at Day 2, Day 5 and Day 8. The following is a reporting template, not a claim that work has occurred.

## Checkpoint report template
- Checkpoint / actual date:
- Planned tasks due by checkpoint:
- Issues completed (number and links):
- Issues in progress:
- Blocked issues and reason:
- Planned cumulative hours:
- Actual cumulative hours (from team time records):
- Planned completion (%):
- Actual completion (%):
- Variance and explanation:
- Upcoming milestone / corrective action:
- Board screenshot filename:

**Progress formula:** Actual completion = (number of completed mandatory tasks ÷ 12) × 100. Also report planned completion separately using the baseline schedule; do not compare actual completion only with the overall project duration. For effort-based earned progress, use completed task estimated hours ÷ 45 hours and label the method clearly.

## Planned checkpoints
| Checkpoint | Expected review |
|---|---|
| Day 2 | M1 deliverables; confirm charter, requirements and WBS; count completed issues |
| Day 5 | M2 status and prototype readiness; inspect blockers and actual hours |
| Day 8 | M3 evidence, test outcomes, CR-01 decision, M4 closure readiness |

## Individual progress update requirement
Each student posts at least three meaningful updates in GitHub Issues. Each update should state work completed, evidence/commit/PR link, next step, blocker (if any), and hours actually spent. Do not copy identical updates or post on behalf of another student.
