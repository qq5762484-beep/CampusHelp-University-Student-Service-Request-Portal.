# Final verification and project closure

## Closure checklist
- [ ] Four milestones reviewed; due dates match confirmed lecturer start date.
- [ ] Twelve mandatory issues exist, assigned to real members and linked to correct milestones.
- [ ] All issues have evidence links and accurate status; no issue closed solely to inflate progress.
- [ ] Board, Table and Roadmap views exist; initiation/midpoint/closure screenshots captured.
- [ ] Each member owns at least four tasks (verify assignment distribution).
- [ ] Three student-authored PRs exist; each has a peer review and merge decision.
- [ ] Each member has at least three meaningful issue progress updates.
- [ ] Risk register reviewed; CR-01 decision recorded.
- [ ] Six tests executed; actual results and Pass/Fail status entered.
- [ ] Final report includes planned versus actual completion, major issues, lessons and unresolved work.

## Planned vs actual
Actual completion, hours, issue counts, PRs, reviews and test results are intentionally left for the team to enter after execution. Attach evidence rather than estimating or inventing results.

## Lessons learned prompts
1. Which dependency most affected delivery, and why?
2. Which requirement changed or was clarified during the project?
3. How did peer review improve a deliverable?
4. Which risk response was effective or ineffective?
5. What would the team change in its next project?

## Unresolved work / limitations
The prototype is not production-ready. Real authentication, secure persistence, role-based authorization, email delivery, audit logs, accessibility testing and integration with university systems remain outside this assignment demonstration.
