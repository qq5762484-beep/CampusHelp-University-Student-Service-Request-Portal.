# Requirements and stakeholder analysis

## Stakeholders
| Stakeholder | Need / concern | Engagement |
|---|---|---|
| Students | Easy submission, confirmation and status visibility | Requirements review; prototype walkthrough |
| IT support | Categorized, prioritized and assignable IT tickets | Review request fields and assignment flow |
| Maintenance staff | Clear classroom/facility issue details and ownership | Review categories and status flow |
| Library staff | Requests routed to the right service team | Validate category taxonomy |
| Administrators | Workload overview, assignment and progress control | Dashboard review and change decisions |
| University Administration (sponsor) | Traceable service process and reporting | Milestone and scope acceptance |

## Functional requirements
| ID | Requirement | Acceptance evidence |
|---|---|---|
| FR-01 | Student can submit a request with student ID, category, description and priority | Request form contains required fields and validation |
| FR-02 | System offers IT Support, Classroom Maintenance, Library Assistance and Administrative Services categories | Category selector contains all four values |
| FR-03 | Student can choose Low, Medium or High priority | Priority selector contains all three values |
| FR-04 | Each submitted request receives a unique request ID | Confirmation displays a unique-looking ID; prototype simulates generation |
| FR-05 | Administrator can assign a request to a responsible team/member | Admin view includes assignee control |
| FR-06 | Request status can be updated and viewed | Status values New, In Progress, Completed are represented |
| FR-07 | Dashboard summarizes open, ongoing and completed requests | Dashboard displays three status totals |

## Non-functional / quality requirements
- NFR-01 Usability: the primary request form is understandable without training.
- NFR-02 Traceability: request ID is visible in the confirmation and tracking list.
- NFR-03 Clarity: status and priority are shown as readable text, not color alone.
- NFR-04 Privacy: mock data only; no real student personal data is stored.
- NFR-05 Scope control: authentication, production persistence and live notifications are explicitly excluded.

## Acceptance boundary
This is a project-management assignment. The prototype demonstrates a user flow with browser-local mock behavior. It is not a production-ready application and does not implement real identity verification, server-side persistence, email delivery or secure access controls.
