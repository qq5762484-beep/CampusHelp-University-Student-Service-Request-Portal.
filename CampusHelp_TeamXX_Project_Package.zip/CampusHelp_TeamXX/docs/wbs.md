# Work Breakdown Structure (WBS)

```text
1.0 CampusHelp project
  1.1 Initiation
    1.1.1 Project charter (T01)
    1.1.2 Stakeholder requirements (T02)
    1.1.3 Scope and WBS (T03)
  1.2 Planning
    1.2.1 Schedule, dependencies and budget (T04)
    1.2.2 Initial wireframes (T05)
    1.2.3 Risk register and quality plan (T06)
  1.3 Execution
    1.3.1 Student request prototype (T07)
    1.3.2 Administrator dashboard prototype (T08)
    1.3.3 Prototype test cases and execution (T09)
  1.4 Monitoring and closure
    1.4.1 Change request evaluation (T10)
    1.4.2 Final verification and issue review (T11)
    1.4.3 Final report and closure documents (T12)
```

## Work package definitions
| WBS | Work package | Output |
|---|---|---|
| 1.1.1 | Establish rationale, objectives, scope, constraints and governance | Approved charter |
| 1.1.2 | Identify stakeholder needs and translate them into requirements | Requirements register |
| 1.1.3 | Decompose scope into deliverable work packages | WBS and scope baseline |
| 1.2.1 | Sequence work, estimate effort and calculate labor budget | Schedule, dependency map, budget |
| 1.2.2 | Sketch student and administrator workflows | Wireframes |
| 1.2.3 | Assess uncertainty and define test/acceptance approach | Risk and quality plans |
| 1.3.1 | Build request submission and confirmation interaction | Student prototype |
| 1.3.2 | Build request queue, assignment and status dashboard | Admin prototype |
| 1.3.3 | Execute six acceptance tests and record outcomes | Test evidence |
| 1.4.1 | Evaluate simulated automatic email acknowledgment request | Change decision record |
| 1.4.2 | Verify evidence, issue state, PR review and milestone status | Verification report |
| 1.4.3 | Consolidate results, lessons and unresolved items | Final report |
