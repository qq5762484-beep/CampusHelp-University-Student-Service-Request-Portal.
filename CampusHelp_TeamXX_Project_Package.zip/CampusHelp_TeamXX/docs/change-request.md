# Change request CR-01 — Automatic email acknowledgment

**Requested on:** Day 6 (assumed 16 Nov 2026)  
**Requester:** University Administration (simulated)  
**Related task:** T10  
**Request:** Automatically send an email acknowledgment whenever a student submits a service request.

## Scope assessment
This feature is outside the original scope baseline, which explicitly excludes live email services. A simulated confirmation screen is in scope; live email delivery is not.

## Impact analysis
- **Effort:** provisional estimate 3 additional hours, as required by the assignment.
- **Cost:** 3 × 50,000 UZS = 150,000 UZS.
- **Revised labor estimate if approved:** 48 hours; 2,400,000 UZS.
- **Schedule:** could consume time reserved for verification/reporting and place M4 at risk unless another task is reduced or the deadline is extended.
- **Dependencies:** affects submission flow and test cases; would require notification behavior and delivery/failure testing.
- **Risks:** external email credentials/service dependency, privacy/data handling, delivery failure and added configuration effort.

## Recommendation: DEFER
Defer live email acknowledgment beyond this academic prototype. Keep an on-screen confirmation state and document the email feature as a future enhancement. This protects the ten-day schedule, avoids external service setup/costs, and respects the stated out-of-scope boundary. If the sponsor later approves it, re-baseline scope, schedule, tests and cost before implementation.

## Decision record
**Decision:** DEFER (proposed project-team recommendation; sponsor/lecturer confirmation to be recorded).  
**Decision owner:** Student A / Project Manager.  
**Date:** Day 6 (confirm actual calendar date).  
**Rationale:** The requested capability is outside scope and the three-hour provisional estimate does not include service configuration, credentials, privacy review or failure handling. No baseline change is made.
