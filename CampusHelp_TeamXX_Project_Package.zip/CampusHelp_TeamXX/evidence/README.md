# Evidence folder
Add genuine screenshots and URLs here after completing GitHub setup and team activities:
- repository-home.png
- collaborators.png
- milestones.png
- labels.png
- board-day2.png, board-day5.png, board-day8-or-closure.png
- table-view.png, roadmap-view.png
- pull-requests-and-reviews/
- issue-progress-updates/
Do not use mock screenshots as evidence of real GitHub activity.
