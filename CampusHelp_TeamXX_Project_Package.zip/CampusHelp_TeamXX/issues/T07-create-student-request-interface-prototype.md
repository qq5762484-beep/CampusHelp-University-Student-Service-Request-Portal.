# T07 — Create student request interface prototype

## Objective
Build a clickable student request form and confirmation flow.

## Description
Create student request interface prototype. Complete the activities defined in the assignment and coordinate with the team. Keep the repository document current and request peer review where appropriate.

## Deliverable
`prototype/index.html`

## Acceptance criteria
Student ID, category, description, priority and submit are present; required-field validation and confirmation/request ID are demonstrated; peer-reviewed.

## Dependency
T05

## Estimated effort
4 hours.

## Priority and milestone
- Priority: High
- Milestone: M3
- Suggested label: `design`

## Completion evidence
Link the committed file, relevant commit and Pull Request here after it exists. Add reviewer feedback and actual time spent. Do not mark complete until evidence has been reviewed.
