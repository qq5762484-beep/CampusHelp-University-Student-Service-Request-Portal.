# T08 — Create administrator dashboard prototype

## Objective
Build an admin view showing requests, assignment and status.

## Description
Create administrator dashboard prototype. Complete the activities defined in the assignment and coordinate with the team. Keep the repository document current and request peer review where appropriate.

## Deliverable
`prototype/index.html`

## Acceptance criteria
Open, ongoing and completed counts are visible; requests show category, priority, assignee and status; peer-reviewed.

## Dependency
T05

## Estimated effort
4 hours.

## Priority and milestone
- Priority: High
- Milestone: M3
- Suggested label: `design`

## Completion evidence
Link the committed file, relevant commit and Pull Request here after it exists. Add reviewer feedback and actual time spent. Do not mark complete until evidence has been reviewed.
