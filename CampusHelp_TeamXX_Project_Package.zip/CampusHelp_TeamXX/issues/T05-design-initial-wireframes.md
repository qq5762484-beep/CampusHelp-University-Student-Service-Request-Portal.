# T05 — Design initial wireframes

## Objective
Design student submission/tracking and administrator dashboard wireframes.

## Description
Design initial wireframes. Complete the activities defined in the assignment and coordinate with the team. Keep the repository document current and request peer review where appropriate.

## Deliverable
`prototype/index.html and docs/requirements-and-stakeholders.md`

## Acceptance criteria
Student form and admin dashboard represent required fields, category, priority, request ID, assignment, statuses and summary counts; peer-reviewed.

## Dependency
T02

## Estimated effort
4 hours.

## Priority and milestone
- Priority: Medium
- Milestone: M2
- Suggested label: `design`

## Completion evidence
Link the committed file, relevant commit and Pull Request here after it exists. Add reviewer feedback and actual time spent. Do not mark complete until evidence has been reviewed.
