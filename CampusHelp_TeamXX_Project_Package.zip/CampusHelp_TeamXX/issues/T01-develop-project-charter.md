# T01 — Develop project charter

## Objective
Define project purpose, scope, objectives, governance and constraints.

## Description
Develop project charter. Complete the activities defined in the assignment and coordinate with the team. Keep the repository document current and request peer review where appropriate.

## Deliverable
`docs/project-charter.md`

## Acceptance criteria
Charter covers scenario, sponsor, PM, stakeholders, duration, budget basis, scope, exclusions, assumptions and at least three measurable success criteria.

## Dependency
None

## Estimated effort
4 hours.

## Priority and milestone
- Priority: High
- Milestone: M1
- Suggested label: `documentation`

## Completion evidence
Link the committed file, relevant commit and Pull Request here after it exists. Add reviewer feedback and actual time spent. Do not mark complete until evidence has been reviewed.
