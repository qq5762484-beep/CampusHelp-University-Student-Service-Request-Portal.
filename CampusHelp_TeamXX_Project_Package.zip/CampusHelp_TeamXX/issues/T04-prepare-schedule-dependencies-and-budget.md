# T04 — Prepare schedule, dependencies and budget

## Objective
Sequence tasks, map dependencies, assign calendar dates and calculate labor budget.

## Description
Prepare schedule, dependencies and budget. Complete the activities defined in the assignment and coordinate with the team. Keep the repository document current and request peer review where appropriate.

## Deliverable
`docs/schedule-and-budget.md`

## Acceptance criteria
All 12 tasks total 45 hours; dependencies match assignment; budget is 2,250,000 UZS at 50,000 UZS/hour; dates confirmed against lecturer start date.

## Dependency
T03

## Estimated effort
4 hours.

## Priority and milestone
- Priority: High
- Milestone: M2
- Suggested label: `planning`

## Completion evidence
Link the committed file, relevant commit and Pull Request here after it exists. Add reviewer feedback and actual time spent. Do not mark complete until evidence has been reviewed.
