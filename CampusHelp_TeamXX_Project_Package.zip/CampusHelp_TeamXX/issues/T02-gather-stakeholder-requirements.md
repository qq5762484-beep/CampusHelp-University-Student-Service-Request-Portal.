# T02 — Gather stakeholder requirements

## Objective
Identify stakeholder needs and define functional and non-functional requirements.

## Description
Gather stakeholder requirements. Complete the activities defined in the assignment and coordinate with the team. Keep the repository document current and request peer review where appropriate.

## Deliverable
`docs/requirements-and-stakeholders.md`

## Acceptance criteria
All six required capabilities are represented; stakeholders and acceptance evidence are documented.

## Dependency
None

## Estimated effort
4 hours.

## Priority and milestone
- Priority: High
- Milestone: M1
- Suggested label: `requirements`

## Completion evidence
Link the committed file, relevant commit and Pull Request here after it exists. Add reviewer feedback and actual time spent. Do not mark complete until evidence has been reviewed.
