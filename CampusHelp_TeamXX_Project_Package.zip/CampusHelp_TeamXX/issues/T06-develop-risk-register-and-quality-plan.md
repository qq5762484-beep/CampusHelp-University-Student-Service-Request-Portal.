# T06 — Develop risk register and quality plan

## Objective
Identify project risks, owners, probability, impact, mitigations and test approach.

## Description
Develop risk register and quality plan. Complete the activities defined in the assignment and coordinate with the team. Keep the repository document current and request peer review where appropriate.

## Deliverable
`docs/risk-register.md; docs/quality-and-test-plan.md`

## Acceptance criteria
At least five risks and six test cases documented; most serious risk justified.

## Dependency
T03

## Estimated effort
4 hours.

## Priority and milestone
- Priority: Medium
- Milestone: M2
- Suggested label: `risk`

## Completion evidence
Link the committed file, relevant commit and Pull Request here after it exists. Add reviewer feedback and actual time spent. Do not mark complete until evidence has been reviewed.
