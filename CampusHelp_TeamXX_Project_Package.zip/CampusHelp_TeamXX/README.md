# CampusHelp — University Student Service Request Portal

Project-management assignment package. This is a planning/prototype project, not a production service.

## Quick start
1. Replace `TeamXX` and the placeholders in `TEAM-DETAILS.md`.
2. Review the assumed schedule in `docs/schedule-and-budget.md`. Baseline assumes Day 1 = 9 Nov 2026; replace dates if the lecturer assigned another start date.
3. Create a GitHub repository named `CampusHelp-TeamXX`, then upload this package.
4. Create milestones, labels and issues using `github-setup.md` and the 12 issue files in `issues/`.
5. Create a GitHub Project board and add the issues; use the field/view configuration in `github-setup.md`.
6. Each real student must create a branch, contribute a file, open a PR, review a peer's PR, and post their own progress updates.
7. Open `prototype/index.html` locally in a browser to demonstrate the clickable mockup.
8. Add genuine GitHub screenshots and actual progress/hours to `evidence/` and the final PDF before submission.

## Package contents
- `docs/`: charter, requirements, stakeholder analysis, WBS, schedule/budget, risks, quality plan, change request, monitoring, closure.
- `issues/`: 12 complete issue descriptions.
- `prototype/`: interactive static HTML prototype.
- `github-setup.md`: repository, milestones, labels, board, fields, views and collaboration checklist.
- `CampusHelp_TeamXX_FinalReport.pdf`: consolidated report draft.

## Important integrity note
This package provides a complete draft and a simulated prototype. It cannot create genuine student identities, accepted invitations, actual GitHub activity, peer reviews, real progress, or screenshots. Those must be completed by the team. GitHub account connection currently exposes no repositories and no repository-creation/project/milestone actions in this session; therefore no live repository or board has been created.
