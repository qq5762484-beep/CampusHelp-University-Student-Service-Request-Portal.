# GitHub setup and verification guide

## Repository
- Name: `CampusHelp-TeamXX`
- Description: `University Student Service Request Portal - Project Management Assignment`
- Visibility: Private unless lecturer directs otherwise
- Initialize with README; ensure Issues are enabled.
- Invite Student B and Student C as collaborators; verify both accept.

## Milestones (create in Issues → Milestones)
| Title | Description | Due date (draft assumption) |
|---|---|---|
| M1 - Project Initiation | Charter, requirements, stakeholders and initial WBS | 2026-11-10 |
| M2 - Project Planning | Schedule, resource estimates, risk register, mockups and quality plan | 2026-11-12 |
| M3 - Project Execution | Student request screen, admin dashboard, prototype demo and test cases | 2026-11-17 |
| M4 - Monitoring and Closure | Change request, verification, final progress and consolidated submission | 2026-11-20 |

**Important:** dates assume Day 1 = 2026-11-09. Confirm lecturer's actual assignment date before creating milestones.

## Labels
Create: `requirements`, `planning`, `design`, `testing`, `documentation`, `risk`, `change-request`, `blocked`.

## Twelve mandatory Issues
Create each file in `issues/` as a separate issue body. Assign the actual student usernames, apply the labels and milestone shown in the issue file. Issue IDs T01–T12 are assignment identifiers; GitHub will allocate issue numbers.

## Project board
Create project: `CampusHelp Project Management - TeamXX`, layout Board. Configure status values `Todo`, `In Progress`, `Done`. Add all twelve repository issues.

Add fields:
- Priority (Single select: High, Medium, Low)
- Estimated Hours (Number)
- Actual Hours (Number)
- Start Date (Date)
- Due Date (Date)
- Status (existing status field)

Create views:
- Board: grouped by Status.
- Table: show title, assignee, status, priority, estimated hours, actual hours, start date, due date and milestone.
- Roadmap: use Start Date and Due Date.

## Branches and pull requests
Each member creates their own branch, contributes at least one meaningful file, opens a PR to `main`, references the relevant issue, and requests a review from another member. Reviewers must inspect the work and submit their own genuine review. Merge only after review and required changes. Record PR URLs in issue evidence.

Suggested branches:
- `student-a-charter-schedule`
- `student-b-requirements-prototype`
- `student-c-wbs-quality`

## Evidence
Save authentic screenshots in `evidence/`: repository home, collaborators, milestones, labels, initial/mid/final board, table, roadmap, each PR/review, issue updates and final issue state. Include working GitHub links in final report.
