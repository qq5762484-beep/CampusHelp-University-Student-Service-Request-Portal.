# Team details — complete before submission

| Role | Full name | Student ID | GitHub username |
|---|---|---|---|
| Student A — Project Manager | TO BE PROVIDED | TO BE PROVIDED | TO BE PROVIDED |
| Student B — Business Analyst & Designer | TO BE PROVIDED | TO BE PROVIDED | TO BE PROVIDED |
| Student C — Quality & Risk Coordinator | TO BE PROVIDED | TO BE PROVIDED | TO BE PROVIDED |

**Team:** TeamXX (replace XX with assigned team number)  
**Repository:** `CampusHelp-TeamXX`  
**Project board:** `CampusHelp Project Management - TeamXX`

Do not claim individual contributions, reviews, approvals, or actual hours until the named students perform and record them.
